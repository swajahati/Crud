import Navbar from "./layout/Navbar";
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Home from './Pages/Home';
import AddUsers from './Users/AddUsers';
import { BrowserRouter as Router,Routes, Route} from 'react-router-dom';
import EditUsers from "./Users/EditUsers";
import ViewUsers from './Users/ViewUsers';
function App() {
  return (
    <div className="App">
    <Router>
     <Navbar/>
     <Routes>
     <Route exact path="/"element = {<Home/>}/>
     <Route path="/adduser" element={<AddUsers />} /> 
     <Route path="/editusers/:id" element={<EditUsers />} />
     <Route path="/viewusers/:id" element={<ViewUsers/>}/>
     </Routes>
      </Router>
    
    </div>
  );
}
export default App;
